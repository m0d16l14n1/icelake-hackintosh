// null analysis for now
